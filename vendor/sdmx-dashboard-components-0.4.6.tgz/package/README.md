# SDMX Dashboard React Component

Embeddable React components to create a dashboard for SDMX data.
The components are built using [Vite](https://vitejs.dev/).

This repository also embeds a demo application to showcase the components (more info [here](#development)).

<sub>Project generated thanks to this great article: [Create a Component Library Fast🚀\(using Vite's library mode\)](https://dev.to/receter/how-to-create-a-react-component-library-using-vites-library-mode-4lma)</sub>

## Usage

This library provides a set of components to build visuals for SDMX data.
Single React components are available `SDMXChart`, `SDMXMap` and `SDMXValue` to embed SDMX visuals in your application and can also be combined in a
 `SDMXDashboard` component that generates a dashboard.
The single components are only configured via props, while the dashboard component can configured via a JSON configuration file.

More information on the syntax of the configuration can be found [here](https://github.com/PacificCommunity/sdmx-dashboard-demo/blob/main/public/doc.md)

```bash
npm install sdmx-dashboard-components
```

The component styles are published as a separate stylesheet. Import it once in your application (for example in the root layout or entry module):

```javascript
import 'sdmx-dashboard-components/dist/sdmx-dashboard-components.css';
```

> **Breaking change in this version:** the CSS is no longer auto-injected by the JavaScript bundle. Importing the stylesheet above is now required for the components to be styled. This change makes the package importable in a server (no-DOM) process; see [Server-side rendering](#server-side-rendering).

```javascript
import { SDMXDashboard } from 'sdmx-dashboard-components';

const App = () => {
  return (
    // SDMX dashboard component build from JSON configuration file
    <SDMXDashboard
      url='path/to/dashboard.json'
    />
    // SDMX chart component built from props
    <SDMXChart
      config={{
        data: ["https://stats-sdmx-disseminate.pacificdata.org/rest/data/SPC,DF_WBWGI,1.0/A..VA_EST?startPeriod=2010&dimensionAtObservation=AllDimensions"],
        title: {
          text: "World Bank Worldwide Governance Indicator",
        },
        subtitle: {
          text: "Voice and Accountability"
        },
        id:"wgi_va",
        type: "drilldown",
        xAxisConcept: "GEO_PICT",
        drilldown: {
          xAxisConcept:"TIME_PERIOD",
        },
        legend: {
          concept: "INDICATOR"
        },
        yAxisConcept: "OBS_VALUE"
      }}
      language='en'
    />
  );
};
```

### Error contract

Every failure in a visual's data pipeline is surfaced as an `SDMXRenderError`, rendered in place of the visual with `role="alert"` and a `data-error-code` attribute. The class and its code type are exported from the package root:

```typescript
import { SDMXRenderError, SDMXRenderErrorCode } from 'sdmx-dashboard-components';
```

| Code | Meaning |
|---|---|
| `ERR_FETCH` | data URL unreachable or non-2xx |
| `ERR_PARSE` | response is not parseable SDMX-JSON |
| `ERR_EMPTY` | query returned zero observations |
| `ERR_NO_SERIES_DIMENSION` | bar/column/lollipop chart with no varying dimension besides the x-axis |
| `ERR_AMBIGUOUS_SERIES` | two or more varying dimensions and no `legend.concept` to disambiguate |
| `ERR_CONCEPT_NOT_FOUND` | `xAxisConcept` or `legend.concept` missing from the dataflow structure |
| `ERR_ENGINE` | anything escaping the charting engine (original error kept as `cause`) |

Errors carry `visualId` (the `id` of the failing visual) and, where useful, a structured `detail` object (for `ERR_CONCEPT_NOT_FOUND` it lists the available concepts; for the series-structure codes it lists the varying dimensions with their value counts). The message wording is part of the public contract and is covered by unit tests: messages name the failing concepts and state concrete fixes, so an agent or a helpful UI can correct the configuration in one step.

### Render lifecycle

Consumers that need to know when a dashboard is ready (live previews, PDF export, agent feedback loops) can observe render state instead of polling the DOM:

```typescript
<SDMXDashboard
  config={config}
  lang="en"
  onVisualRender={(s: VisualRenderStatus) => void}      // fires per visual, on every state change
  onRenderComplete={(all: VisualRenderStatus[]) => void} // fires once per config when no visual is loading
/>
```

Each `VisualRenderStatus` carries the `visualId`, a `status` of `loading`, `rendered`, `empty`, or `error`, the `SDMXRenderError` when failed, and on success a `stats` block (`observationCount`, `seriesCount`, `timePeriodRange`) that lets a consumer judge whether a technically successful render is substantively thin. `onRenderComplete` fires exactly once per config change, after the last visual settles, including the case where every visual fails. The standalone `SDMXChart`, `SDMXValue`, and `SDMXMap` accept `onVisualRender` as well. Both callbacks are optional.

### Table visual

`type: "table"` renders a tabular visual: the `xAxisConcept` becomes the table rows and an optional `legend.concept` is pivoted across the columns (without it, a single value column is shown). It reuses the same data, error, lifecycle, and fetcher behaviour as the other visuals.

```javascript
<SDMXTable
  config={{
    id: 'pop-table',
    type: 'table',
    xAxisConcept: 'TIME_PERIOD',
    legend: { concept: 'GEO_PICT' },
    data: 'https://.../rest/data/SPC,DF_POP,1.0/...?dimensionAtObservation=AllDimensions'
  }}
  language='en'
/>
```

### Exported types

The configuration types are exported from the package root: `SDMXDashboardConfig`, `SDMXDashboardRow`, `SDMXVisualConfig`, `SDMXChartConfig`, `SDMXMapConfig`, `SDMXTableConfig`, `SDMXTextConfig`, and `SDMXColorPalette`.

> **Deprecation:** dashboard rows accept their visuals under `columns`. The earlier misspelling `colums` is still accepted as an alias for one major version; migrate to `columns`.

> **Note on `extraOptions`:** `extraOptions` passes raw Highcharts options straight through and is typed `Record<string, unknown>`. It is engine-bound and not supported across major versions (a charting-engine change can break stored `extraOptions`). Prefer the semantic config fields where they exist.

### Accessibility

The components target WCAG 2.1 AA:

- The charting engine's accessibility module is enabled, exposing the chart to assistive technology and adding keyboard support.
- Every chart also renders a visually hidden data table holding the same observations, so a screen reader can read the data even where the chart vocabulary falls short. The native `table` visual provides the same data as a visible table.
- Title and unit configuration flow into the accessible description of each visual.

**Keyboard behaviour** (provided by the charting engine's accessibility module): when a chart is focused, press `Tab` to move focus into it, the arrow keys to move between data points within a series, and `Tab` again to move to the next series or out of the chart. The visually hidden data table is reachable in normal reading and table-navigation order.

### Global theming

A `theme` prop applies institutional branding once at the dashboard level (and is accepted by the standalone components), so styling no longer has to be repeated per visual or applied through internal engine class names:

```typescript
const spcTheme: SDMXTheme = {
  palette: ['#0a4595', '#e63946', '#2a9d8f'], // series colours in order
  fontFamily: { display: 'Georgia, serif', data: 'Inter, sans-serif' },
  numberFormat: { locale: 'en-NZ', decimalSeparator: '.' }
};

<SDMXDashboard config={config} theme={spcTheme} />
```

A per-visual `colorPalette` keeps precedence over the theme palette, and any field the theme leaves unset falls back to the engine default. `numberFormat.locale` overrides the component language for number formatting (values, data labels, table cells) while leaving translated text on the component language.

### Engine neutrality

Most of the configuration schema is engine-neutral, so the underlying charting engine can change without breaking consumers who stay on the documented API. Two things to know:

- **Render target.** Charts render to inline **SVG**. Consumers that post-process the output (for example converting chart SVG to canvas for PDF export) can rely on this as part of the public contract; a change to the render target would be a major-version note.
- **Semantic vs engine-bound config.** Prefer the semantic fields (`title`, `subtitle`, `unit`, `xAxisTitle`, `yAxisTitle`, `colorPalette`, `legend`) over `extraOptions`. `extraOptions` is a passthrough of raw engine options and is not guaranteed across major versions. Styling through internal engine CSS class names is likewise unsupported; use the documented config instead.

### Server-side rendering

The package is side-effect-free at import time: it touches no `window`, `document`, or charting-engine globals until a component first renders on the client. `import { SDMXDashboard } from 'sdmx-dashboard-components'` therefore succeeds in a Node.js process with no DOM, and a server-rendered framework (Next.js and similar) can use the components directly, with no `dynamic(ssr: false)` wrapper. Components render a placeholder on the server and hydrate into charts on the client. Remember to import the stylesheet (see [Usage](#usage)); the engine feature modules register on first client render.

### Interaction callback

Click events on chart elements are exposed through `onUserInteraction`, on the dashboard and on `SDMXChart`:

```typescript
<SDMXDashboard
  config={config}
  onUserInteraction={(e: VisualInteraction) => void}
  // { visualId, kind: "point-click" | "series-click" | "legend-click",
  //   concepts: { REF_AREA: "WS", INDICATOR: "POP", ... }, value?, timePeriod? }
/>
```

The `concepts` map gives the dimension coordinate of the interaction point as dimension id to code, enough to reconstruct the SDMX query for the clicked slice without engine knowledge on the consumer side. The callback is optional and adds no behaviour when absent.

### Custom loading, empty, and error states

The built-in loading, empty, and error presentations can be replaced per state with render slots, on the dashboard and on the standalone components:

```typescript
<SDMXDashboard
  config={config}
  renderLoading={(visualId) => <BrandedSpinner />}
  renderEmpty={(visualId) => <BrandedNoDataCard />}
  renderError={(e: SDMXRenderError) => <BrandedErrorCard code={e.code} message={e.message} />}
/>
```

Defaults reproduce the built-in behaviour. `renderEmpty` applies when a query returns zero observations (`ERR_EMPTY`); other failures go to `renderError`. The map has no loading presentation of its own, so it uses only `renderEmpty` and `renderError`.

### Custom data transport

All components accept an optional `fetcher` prop with the signature of the global `fetch` (`(url, init?) => Promise<Response>`). When provided, every request made by the library (the dashboard configuration and all SDMX data queries) goes through it, so the integrating application can add authentication headers, route requests through a proxy, or apply caching and retries without touching the global `fetch`. When absent, the global `fetch` is used.

```javascript
const proxyFetcher = (url, init) =>
  fetch(url.replace('https://stats-sdmx-disseminate.pacificdata.org', '/api/sdmx-proxy'), init);

<SDMXDashboard url='path/to/dashboard.json' fetcher={proxyFetcher} />
```

Routing the SDMX data queries through the fetcher requires an sdmx-json-parser version whose `getDatasets` accepts the `fetcher` option; on older parser versions the data queries fall back to the global `fetch`. The GeoJSON layers of `SDMXMap` are loaded by OpenLayers and do not go through the fetcher.

### Request dedup, caching, retry, and telemetry

The library wraps its data requests in a transport layer, on top of the provided `fetcher` or the global `fetch`:

- identical in-flight URLs across the visuals of a dashboard share one network request;
- responses are cached for the lifetime of the rendered config (a config or language change invalidates);
- network errors and 5xx responses are retried once with a short backoff, 4xx fails immediately.

Operators can observe endpoint behaviour through the `onDataFetch` callback, available on the dashboard and the standalone components:

```typescript
<SDMXDashboard
  config={config}
  onDataFetch={(t: FetchTelemetry) => void} // { url, host, status, durationMs, fromCache, retried }
/>
```

It fires once per settled request, including deduplicated cache hits (`fromCache: true`), with no double counting of the underlying network exchange.

### Highcharts Styled Mode

The user can also make use of all the Highcharts options passing them as props to the components with the `extraOptions` parameter of the config object.

For instance, the Highcharts `styledMode` option can be used to apply CSS styles to the chart's elements and also leverage the dark theme. In this case, the `colorPalette` parameter passed to the component must be an object that specify a colorIndex and not a color code. The integrating application has to include in its CSS the highcharts classes for the indexes. 

```javascript
<SDMXChart
  config={{
    data: ["https://stats-sdmx-disseminate.pacificdata.org/rest/data/SPC,DF_WBWGI,1.0/A..VA_EST?startPeriod=2010&dimensionAtObservation=AllDimensions"],
    title: {
      text: "World Bank Worldwide Governance Indicator",
    },
    colorPalette: {
      "GEO_PICT": {
        "CK": 0,
        "FJ": 1,
        "FM": 2,
        "KI": 3,
        "MH": 4,
        "NC": 5,
        "PF": 8,
        "PW": 10,
        "SB": 11,
        "TO": 12,
        "VU": 14,
        "WF": 15
      }
    },
    extraOptions: {
      chart: {
        styledMode: true
      }
    }
  }}
/>
```

```css
.highcharts-color-0 {
  fill: #E16A86;
  stroke: #E16A86;
}
.highcharts-color-1 {
  fill: #D7765B;
  stroke: #D7765B;
}
.highcharts-color-2 {
  fill: #C7821C;
  stroke: #C7821C;
}
...
```

### Sorting data by value

For `column`-like representation (`column`, `bar`, `drilldown`, `lollipop`), the data is sorted alphabetically by default. The data can be sorted by value with the `sortByValue` config parameter in ascending or descending order. The sorting is done on the x-axis dimension.

```javascript
<SDMXChart
  config={{
    ...
    sortByValue: "asc" | "desc"
    ...
  }}
/>
```

## Development

```bash
npm install
npm run dev
```

The components are located in the `lib` folder where as the `src` folder hosts a demo application.

The vite preview mode can also be used to test the built library in the demo application.

```bash
npm run preview
```

To deploy the demo app under a subfolder only in production, set `VITE_DEMO_BASE_PATH`.

```bash
# Example: deploy demo to /sdmx-dashboard-components/
VITE_DEMO_BASE_PATH=sdmx-dashboard-components npm run build-preview
```

When `VITE_DEMO_BASE_PATH` is empty (default), the demo is built for root (`/`).


## Build

```bash
npm run build
```

